package com.announcify.api.background.text;

import android.content.Context;

public class TextFilter {

    public static boolean announcable(final Context context, final String text) {
        // TODO: spam filter

        return true;
    }
}
