package com.announcify.api.simple;

import android.content.Context;

import com.announcify.api.background.sql.model.PluginModel;

public class SimplePluginModel extends PluginModel {

    public SimplePluginModel(final Context context) {
        super(context);
    }

}
